﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnergyCounter
{
    public class HotKeys
    {
        public string Reset1st { get; set; }
        public string Reset2nd { get; set; }
        public string AddMain { get; set; }
        public string AddAlternative { get; set; }
        public string SubtractMain { get; set; }
        public string SubtractAlternative { get; set; }
    }
}
