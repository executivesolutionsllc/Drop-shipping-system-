﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnergyCounter
{
    public class EnergyModel
    {
        public int EnergyCount { get; set; }
    }
}
