﻿using AForge.Video.DirectShow;
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;

namespace RemoteLiveCamara
{
    class Program
    {
        
        static void Main(string[] args)
        {
            // 枚举所有视频输入设备
           

           
          

            while (true) Thread.Sleep(1);
        }
    }
}
